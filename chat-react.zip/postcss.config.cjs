/* eslint-disable no-undef */
module.exports = {
    plugins: {
        autoprefixer: {}
    }
}